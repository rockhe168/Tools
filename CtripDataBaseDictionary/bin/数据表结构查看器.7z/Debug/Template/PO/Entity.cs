﻿// -----------------------------------------------------------------------
// <copyright file="{TableName}.cs" company="Microsoft">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace {NameSpace}
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Package.Framework2.Data;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public class {TableName}PO : ITableEntity
    {
        public const string TABLE_NAME_SELECT = "{DataBaseName}_SELECT.{TableName}";
        public const string TABLE_NAME_INSERT = "{DataBaseName}_SAVE.{TableName}";

        {ProPertyList}
    }
}
